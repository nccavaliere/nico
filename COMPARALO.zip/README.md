# COMPARALO
Sistema comparador de precios con login, carrito, panel de admin y más.