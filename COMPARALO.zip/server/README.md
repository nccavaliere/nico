# Backend Node.js
Este es el backend de COMPARALO.